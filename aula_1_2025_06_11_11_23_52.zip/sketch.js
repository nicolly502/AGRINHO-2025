let cidade;
let campo;
let conexao = [];

function setup() {
  createCanvas(600, 400);
  cidade = createVector(width - 100, height / 2); // Posição da cidade
  campo = createVector(100, height / 2);  // Posição do campo
  noFill();
}

function draw() {
  background(220);

  // Desenho do campo
  fill(100, 200, 100);
  ellipse(campo.x, campo.y, 100, 100); // Representação do campo

  // Desenho da cidade
  fill(200, 100, 100);
  rect(cidade.x - 50, cidade.y - 50, 100, 100); // Representação da cidade

  // Desenho das conexões
  stroke(0);
  for (let i = 0; i < conexao.length; i++) {
    line(campo.x, campo.y, conexao[i].x, conexao[i].y);
    line(cidade.x, cidade.y, conexao[i].x, conexao[i].y);
  }

  // Se a conexão for concluída
  if (conexao.length > 0) {
    textSize(32);
    textAlign(CENTER, CENTER);
    fill(0);
    text("Conexão Realizada!", width / 2, height - 30);
  }
}

function mousePressed() {
  // Criação de um ponto de conexão
  conexao.push(createVector(mouseX, mouseY));
}
